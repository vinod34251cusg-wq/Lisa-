package com.lisa.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.content.Context
import java.util.Locale
import kotlin.random.Random

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var tts: TextToSpeech
    private var recognizer: SpeechRecognizer? = null
    private lateinit var status: TextView
    private lateinit var conversation: TextView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("lisa_memory", Context.MODE_PRIVATE) }
    private val purple = Color.rgb(117, 75, 190)
    private val greetings = listOf(
        "Good morning Sir! Aaj kya plan hai?",
        "Ji Sir, bataiye... aaj kis baare mein baat karein?",
        "Hello Sir! Aaj main aapki kya help kar sakti hoon?",
        "Welcome back Sir! Kya naya karna hai aaj?",
        "Sir, main ready hoon. What can I help you with today?"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        showMessage("LISA", greetings.random())
        requestMicPermission()
    }

    private fun buildUi() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.rgb(17, 13, 28))
        }
        val title = TextView(this).apply {
            text = "LISA AI"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your personal offline assistant"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Ready, Sir"
            textSize = 14f
            setTextColor(Color.rgb(190, 160, 255))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 12)
        }
        conversation = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(14, 14, 14, 14)
        }
        val scroll = ScrollView(this).apply {
            addView(conversation)
            setBackgroundColor(Color.rgb(31, 25, 45))
        }
        input = EditText(this).apply {
            hint = "Type a message..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setSingleLine(true)
        }
        val send = makeButton("Send") { handleCommand(input.text.toString()); input.setText("") }
        val mic = makeButton("🎙  Talk to LISA") { startListening() }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(send, LinearLayout.LayoutParams(0, -2, 1f))
            addView(mic, LinearLayout.LayoutParams(0, -2, 1f))
        }
        page.addView(title)
        page.addView(subtitle)
        page.addView(status)
        page.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        page.addView(input)
        page.addView(row)
        setContentView(page)
    }

    private fun makeButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        setTextColor(Color.WHITE)
        setBackgroundColor(purple)
        setOnClickListener { action() }
    }

    private fun showMessage(who: String, message: String) {
        conversation.append("$who: $message\\n\\n")
        (conversation.parent as? ScrollView)?.post { (conversation.parent as ScrollView).fullScroll(View.FOCUS_DOWN) }
        if (who == "LISA") speak(message)
    }

    private fun speak(text: String) {
        if (::tts.isInitialized) {
            val language = if (text.any { it in 'अ'..'ह' }) Locale("hi", "IN") else Locale.UK
            val result = tts.setLanguage(language)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.getDefault()
            }
            tts.setSpeechRate(0.88f)
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lisa_${System.currentTimeMillis()}")
        }
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.setSpeechRate(0.88f)
            status.text = "Voice ready • Sir"
        }
    }

    private fun requestMicPermission() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 21)
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestMicPermission()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "Speech recognition is not available on this phone."
            return
        }
        try {
            recognizer?.destroy()
            recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening, Sir..." }
                override fun onBeginningOfSpeech() { status.text = "I'm listening..." }
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Processing..." }
                override fun onError(error: Int) {
                    status.text = "Voice input unavailable. Check offline language support."
                }
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) {
                        showMessage("Sir", text)
                        handleCommand(text)
                    }
                    status.text = "Ready, Sir"
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            status.text = "Could not start voice recognition."
        }
    }

    private fun handleCommand(raw: String) {
        val text = raw.trim()
        if (text.isBlank()) return
        val lower = text.lowercase(Locale.ROOT)

        when {
            lower.contains("open youtube") || lower.contains("youtube kholo") ->
                launchPackage("com.google.android.youtube", "YouTube")
            lower.contains("open camera") || lower.contains("camera kholo") ->
                launchCamera()
            lower.contains("open maps") || lower.contains("maps kholo") || lower.contains("map kholo") ->
                launchPackage("com.google.android.apps.maps", "Maps")
            lower.contains("open chrome") || lower.contains("chrome kholo") ->
                launchPackage("com.android.chrome", "Chrome")
            lower.contains("open settings") || lower.contains("settings kholo") ->
                launchSettings()
            lower.startsWith("remember ") || lower.startsWith("yaad rakhna ") -> {
                val memory = text.substringAfter(" ", "").trim()
                if (memory.isNotBlank()) {
                    prefs.edit().putString("memory_${System.currentTimeMillis()}", memory).apply()
                    reply("Ji Sir, maine ye baat is phone mein save kar li hai.")
                } else reply("Sir, kya yaad rakhna hai?")
            }
            lower.contains("what do you remember") || lower.contains("meri preferences") || lower.contains("kya yaad hai") ->
                showMemories()
            lower.contains("hello") || lower.contains("hi lisa") || lower.contains("namaste") ->
                reply(greetings.random())
            lower.contains("your name") || lower.contains("naam kya") ->
                reply("Sir, mera naam LISA hai. I'm your personal assistant.")
            lower.contains("time") || lower.contains("samay") ->
                reply("Sir, abhi " + java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date()) + " hue hain.")
            lower.contains("date") || lower.contains("tarikh") || lower.contains("tareekh") ->
                reply("Sir, aaj " + java.text.SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()).format(java.util.Date()) + " hai.")
            lower.contains("help") || lower.contains("kya kar") ->
                reply("Sir, main YouTube, Camera, Maps, Chrome aur Settings open kar sakti hoon. Aap mujhe koi preference yaad rakhne ko bhi keh sakte hain.")
            else ->
                reply("Sir, abhi main offline basic assistant mode mein hoon. Is request ka jawab dene ke liye local AI model integration chahiye.")
        }
    }

    private fun reply(message: String) = showMessage("LISA", message)

    private fun showMemories() {
        val all = prefs.all.filterKeys { it.startsWith("memory_") }.values.mapNotNull { it as? String }
        reply(if (all.isEmpty()) "Sir, abhi aapne mujhe koi memory save nahi karwayi." else
            "Sir, mujhe ye baatein yaad hain: " + all.takeLast(5).joinToString(". "))
    }

    private fun launchPackage(packageName: String, label: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            startActivity(launch)
            reply("Ji Sir, $label open kar rahi hoon.")
        } else reply("Sir, $label app is phone par nahi mili.")
    }

    private fun launchCamera() {
        try {
            startActivity(Intent("android.media.action.IMAGE_CAPTURE"))
            reply("Ji Sir, Camera open kar rahi hoon.")
        } catch (_: Exception) { reply("Sir, Camera open nahi ho paaya.") }
    }

    private fun launchSettings() {
        try {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            reply("Ji Sir, Settings open kar rahi hoon.")
        } catch (_: Exception) { reply("Sir, Settings open nahi ho paayi.") }
    }

    override fun onDestroy() {
        recognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
