# LISA AI — Android starter project

## Is ZIP mein kya hai?
- Native Android Studio project (Kotlin)
- Hindi/English mixed text commands
- Text-to-speech replies with a slower speech rate
- Microphone speech input (offline mode preferred when device supports it)
- YouTube, Camera, Maps, Chrome, Settings launch commands
- Local preference/memory storage using SharedPreferences
- Different greeting lines

## Important limitations (honest status)
1. Ye **source project ZIP hai, APK nahi**. Is ZIP ko Android Studio mein build karke APK banani hogi.
2. Offline speech recognition tabhi chalegi jab phone ke speech service mein Hindi offline language pack installed/supported ho. `EXTRA_PREFER_OFFLINE` ek preference hai, guarantee nahi.
3. Is version mein full local LLM/4GB AI model bundled nahi hai. Unknown questions par app clearly batati hai ki local AI integration abhi baaki hai.
4. Is version mein speaker identity / voiceprint recognition nahi hai. Microphone speech-to-text ko speaker recognition samajhna galat hoga. Voice identity ko authentication ke liye use na karein.
5. Female voice ka selection Android TTS engine aur installed voices par depend karta hai; app engine ki default Hindi/English voice use karti hai. Speech rate slow set hai, voice gender guaranteed nahi.
6. API key ya cloud service ki zaroorat nahi hai for the included basic features.

## Build karne ka tareeqa
1. Computer par Android Studio install karein.
2. ZIP extract karein.
3. Android Studio > Open > extracted `LISA_AI_Final_Project` folder.
4. Gradle sync complete hone dein (Android SDK 35 and compatible Gradle/Android plugin download ho sakte hain).
5. Phone ko USB debugging se connect karein, ya Build > Build APK(s) select karein.
6. APK output usually `app/build/outputs/apk/debug/app-debug.apk` mein milega.
7. Phone par install karke microphone permission allow karein.

## Voice commands (example)
- "Open YouTube" / "YouTube kholo"
- "Open Camera" / "Camera kholo"
- "Open Maps" / "Maps kholo"
- "Open Chrome" / "Chrome kholo"
- "Open Settings" / "Settings kholo"
- "Remember my favourite colour is purple"
- "What do you remember?"
- "What time is it?"

## Requirements
- Android Studio with Android SDK 35
- Android phone Android 8.0+ (API 26+)
- Android Speech Recognition service and TTS engine for voice features
